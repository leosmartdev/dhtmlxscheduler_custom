dhtmlxScheduler v.4.4.9 Professional

This software is covered by DHTMLX Enterprise License. Usage without proper license is prohibited.

(c) Dinamenta, UAB.


Useful links
-------------

- Online  documentation
	https://docs.dhtmlx.com/scheduler/
- Downloadable documentation
	CHM version
		https://docs.dhtmlx.com/chm/scheduler.chm.zip
	HTML version
		https://dhtmlx.com/regular/dhtmlxScheduler_docs_html.zip
- Support forum
	https://forum.dhtmlx.com/viewforum.php?f=6
- Skin builder
	https://dhtmlx.com/docs/products/dhtmlxScheduler/skinBuilder/index.shtml


Other editions
--------------

- MVC.Net edition
	http://scheduler-net.com
- Scheduler for mobile devices
	https://dhtmlx.com/x/download/regular/dhtmlxScheduler_mobile.zip