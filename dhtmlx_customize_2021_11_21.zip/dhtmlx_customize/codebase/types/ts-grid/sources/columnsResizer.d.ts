import { Grid } from "./Grid";
export declare function startResize(grid: Grid, column: string, ev: MouseEvent & TouchEvent, cb: any): void;
