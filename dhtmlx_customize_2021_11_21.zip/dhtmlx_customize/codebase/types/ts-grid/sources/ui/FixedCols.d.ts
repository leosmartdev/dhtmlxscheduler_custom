import { ILayoutState, IRendererConfig } from "./../types";
export declare function getFixedColsHeader(renderConfig: IRendererConfig, layout: ILayoutState): any;
export declare function getFixedCols(renderConfig: IRendererConfig, layout: ILayoutState): any[];
