import { IRendererConfig, ICol, IEditor } from "../../types";
export declare function getEditor(row: any, col: ICol, conf: IRendererConfig): IEditor;
