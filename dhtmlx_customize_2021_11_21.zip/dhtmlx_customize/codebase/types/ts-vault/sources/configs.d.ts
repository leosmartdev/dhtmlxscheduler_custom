export declare const layoutConfig: {
    css: string;
    rows: {
        id: string;
        css: string;
    }[];
};
export declare const layoutConfigWithoutTopbar: {
    css: string;
    rows: {
        id: string;
        css: string;
    }[];
};
