export declare function selectAllView(): any;
export declare function unselectAllView(): any;
export declare function emptyListView(): any;
