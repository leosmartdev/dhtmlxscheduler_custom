import { IMessageProps } from "./types";
export declare function message(props: string | IMessageProps): void;
