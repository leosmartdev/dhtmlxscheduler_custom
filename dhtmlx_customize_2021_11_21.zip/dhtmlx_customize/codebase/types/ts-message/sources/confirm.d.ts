import { IConfirmProps } from "./types";
export declare function confirm(props: IConfirmProps): Promise<unknown>;
