export declare function blockScreen(css?: string): () => void;
