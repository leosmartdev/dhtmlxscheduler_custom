export declare function legendShape(form: any, item: any): any;
