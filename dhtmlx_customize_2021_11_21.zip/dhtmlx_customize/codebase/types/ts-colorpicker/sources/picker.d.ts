import { IPickerState } from "./types";
import { Colorpicker } from "./Colorpicker";
export declare function getPicker(colorpicker: Colorpicker, pickerState: IPickerState, handlers: any): any;
export declare function calculatePaletteGrip(rootView: any, top: number, left: number): void;
