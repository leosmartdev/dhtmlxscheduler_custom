export declare function navItem(item: any, widgetName: string, collapsed?: boolean): any;
