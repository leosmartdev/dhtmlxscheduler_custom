export declare function datePicker(item: any, events: any, widgetName: string): any;
