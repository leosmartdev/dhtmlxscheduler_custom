export declare function input(item: any, events: any, widgetName: string): any;
